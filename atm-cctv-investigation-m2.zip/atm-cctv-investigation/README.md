# ATM CCTV Investigation — local prototype

A local-only investigator-support prototype. Use only synthetic or authorised hackathon sample footage. The application does not identify people; all candidate observations require human verification.

## Backend (Windows PowerShell)

```powershell
cd "C:\RP Hackathon\atm-cctv-investigation\backend"
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[dev]"
uvicorn atmface.main:app --reload --host 127.0.0.1 --port 8000
```

If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` in that terminal, then activate again.

## Frontend (a second PowerShell window)

```powershell
cd "C:\RP Hackathon\atm-cctv-investigation\frontend"
npm install
npm run dev
```

Open `http://127.0.0.1:5173`. API documentation: `http://127.0.0.1:8000/docs`.

## M2 video intake

- Supported extensions: MP4, AVI, MKV.
- Default upload limit: 500 MB. Override with `ATMFACE_MAX_UPLOAD_BYTES` before starting the backend.
- OpenCV validates that the upload can be opened and decoded, extracts duration/FPS/frame count/resolution, and creates a JPEG preview.
- SHA-256 is calculated from the uploaded bytes.
- Original uploads are stored unchanged under `backend/storage/originals`; previews and JSON metadata are stored separately.
- No video is uploaded to a remote service.

Storage folders are created automatically. Do not use this prototype with real personal data or operational CCTV without the required authorisation, security review, retention policy and legal approval.

## Tests

With the backend virtual environment active:

```powershell
pytest
```
