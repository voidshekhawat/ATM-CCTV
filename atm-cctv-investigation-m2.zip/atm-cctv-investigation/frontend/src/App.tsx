import { ChangeEvent, useEffect, useState } from "react";

type Health = { status: string; service: string; mode: string };
type Video = {
  video_id: string;
  original_filename: string;
  format: string;
  size_bytes: number;
  sha256: string;
  uploaded_at: string;
  processing_status: string;
  duration_seconds: number;
  fps: number;
  frame_count: number;
  width: number;
  height: number;
  thumbnail_url: string;
};
const API = "http://127.0.0.1:8000";

function formatBytes(bytes: number) {
  return bytes >= 1024 * 1024
    ? `${(bytes / (1024 * 1024)).toFixed(1)} MB`
    : `${(bytes / 1024).toFixed(0)} KB`;
}
function formatDuration(seconds: number) {
  const minutes = Math.floor(seconds / 60);
  const remaining = Math.floor(seconds % 60);
  return `${minutes}:${String(remaining).padStart(2, "0")}`;
}

export default function App() {
  const [health, setHealth] = useState<Health | null>(null);
  const [apiError, setApiError] = useState("");
  const [videos, setVideos] = useState<Video[]>([]);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState("");
  const [activePage, setActivePage] = useState("Overview");

  async function refreshVideos() {
    const response = await fetch(`${API}/videos`);
    if (!response.ok) throw new Error("Could not load the video library.");
    const data = (await response.json()) as { items: Video[] };
    setVideos(data.items);
  }

  useEffect(() => {
    fetch(`${API}/health`)
      .then((response) => {
        if (!response.ok) throw new Error(`API returned ${response.status}`);
        return response.json() as Promise<Health>;
      })
      .then(setHealth)
      .catch((error: Error) => setApiError(error.message));
    refreshVideos().catch(() => undefined);
  }, []);

  async function handleUpload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    setMessage("");
    setUploading(true);
    try {
      const body = new FormData();
      body.append("file", file);
      const response = await fetch(`${API}/videos/upload`, { method: "POST", body });
      const result = await response.json();
      if (!response.ok) throw new Error(result.detail || "Upload failed.");
      setMessage(`Uploaded and validated: ${result.original_filename}`);
      await refreshVideos();
      setActivePage("Video Analysis");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Upload failed.");
    } finally {
      setUploading(false);
      event.target.value = "";
    }
  }

  const isVideoPage = activePage === "Video Analysis";
  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand-mark">RP</div>
        <div className="brand-copy"><strong>ATM FORENSICS</strong><span>LOCAL INVESTIGATION SUITE</span></div>
        <nav>
          {["Overview", "New Investigation", "Video Analysis", "Face Search", "Evidence Centre", "Audit Log"].map((item) =>
            <button key={item} className={activePage === item ? "active" : ""} onClick={() => setActivePage(item)}>{item}</button>
          )}
        </nav>
        <div className="sidebar-note">LOCAL MODE<br /><span>Data remains on this device.</span></div>
      </aside>
      <section className="main">
        <header>
          <div><p className="eyebrow">INVESTIGATOR WORKSPACE</p><h1>{isVideoPage ? "Video Analysis" : activePage}</h1></div>
          <div className="status-pill"><i /> LOCAL SYSTEM</div>
        </header>
        {isVideoPage ? <>
          <section className="welcome compact"><div><p className="eyebrow">MILESTONE 02 · MEDIA INTAKE</p><h2>Authorised CCTV footage</h2><p>Upload sample footage to validate the file, extract technical metadata and create a preview. Original bytes are retained unchanged.</p></div><div className="welcome-symbol">▣</div></section>
          <section className="panel upload-panel">
            <div className="panel-heading"><div><p className="eyebrow">VIDEO INGESTION</p><h3>Add a video file</h3></div><span className="badge">MP4 · AVI · MKV</span></div>
            <label className={`upload-zone ${uploading ? "disabled" : ""}`}>
              <input type="file" accept=".mp4,.avi,.mkv,video/mp4,video/x-msvideo,video/x-matroska" onChange={handleUpload} disabled={uploading} />
              <span className="upload-icon">↑</span><strong>{uploading ? "Uploading and validating…" : "Choose CCTV video"}</strong>
              <small>Maximum file size: 500 MB · Processed locally on this computer</small>
            </label>
            {message && <p className="notice">{message}</p>}
          </section>
          <section className="panel">
            <div className="panel-heading"><div><p className="eyebrow">LOCAL MEDIA LIBRARY</p><h3>Uploaded videos ({videos.length})</h3></div><button className="refresh" onClick={() => refreshVideos().catch((e: Error) => setMessage(e.message))}>Refresh</button></div>
            {videos.length === 0 ? <p className="empty">No videos uploaded yet. Use the upload area above to add authorised sample footage.</p> :
              <div className="video-list">{videos.map((video) => <article className="video-row" key={video.video_id}>
                <img src={`${API}${video.thumbnail_url}`} alt="Video preview frame" />
                <div className="video-info"><strong>{video.original_filename}</strong><span>{video.width} × {video.height} · {video.fps} FPS · {formatDuration(video.duration_seconds)} · {formatBytes(video.size_bytes)}</span><small>SHA-256: {video.sha256}</small><small>Uploaded: {new Date(video.uploaded_at).toLocaleString()}</small></div>
                <span className="badge good">{video.processing_status.toUpperCase()}</span>
              </article>)}</div>}
          </section>
        </> : <>
          <section className="welcome"><div><p className="eyebrow">ATM CCTV ANALYSIS</p><h2>Investigation workspace</h2><p>Review authorised sample footage, examine transaction-linked candidates, and prepare traceable evidence.</p></div><div className="welcome-symbol">⌕</div></section>
          <section className="cards">
            <article><span>ACTIVE CASES</span><strong>—</strong><small>Database milestone pending</small></article>
            <article><span>VIDEOS UPLOADED</span><strong>{videos.length}</strong><small>Local media library</small></article>
            <article><span>FACES EXTRACTED</span><strong>—</strong><small>Vision pipeline pending</small></article>
            <article><span>SEARCH RUNS</span><strong>—</strong><small>Search index pending</small></article>
          </section>
          <section className="panel"><div className="panel-heading"><div><p className="eyebrow">SYSTEM CHECK</p><h3>Backend connection</h3></div><span className={health ? "badge good" : "badge"}>{health ? "CONNECTED" : "WAITING"}</span></div>{health ? <p className="connection">API online · {health.service} · {health.mode}</p> : <p className="connection">{apiError || "Start the backend to connect this workspace."}</p>}</section>
          <button className="primary-action" onClick={() => setActivePage("Video Analysis")}>Open Video Analysis →</button>
        </>}
        <p className="disclaimer">Authorised sample footage only. Technical metadata and previews are not identity determinations. Human verification is required.</p>
      </section>
    </main>
  );
}
