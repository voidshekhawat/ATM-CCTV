from __future__ import annotations

import hashlib
import json
import os
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path

import cv2
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

BASE_DIR = Path(__file__).resolve().parents[2]
STORAGE_DIR = BASE_DIR / "storage"
ORIGINALS_DIR = STORAGE_DIR / "originals"
THUMBNAILS_DIR = STORAGE_DIR / "thumbnails"
TEMP_DIR = STORAGE_DIR / "temporary"
METADATA_DIR = STORAGE_DIR / "metadata"
for directory in (ORIGINALS_DIR, THUMBNAILS_DIR, TEMP_DIR, METADATA_DIR):
    directory.mkdir(parents=True, exist_ok=True)

ALLOWED_EXTENSIONS = {".mp4", ".avi", ".mkv"}
MAX_UPLOAD_BYTES = int(os.getenv("ATMFACE_MAX_UPLOAD_BYTES", str(500 * 1024 * 1024)))
CHUNK_SIZE = 1024 * 1024

app = FastAPI(
    title="ATM CCTV Investigation API",
    version="0.2.0",
    description=(
        "Local investigator-support prototype. Uploaded sample footage is stored locally. "
        "Video metadata and previews are technical observations, not identity determinations."
    ),
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)
app.mount("/storage/thumbnails", StaticFiles(directory=THUMBNAILS_DIR), name="thumbnails")


def _metadata_path(video_id: str) -> Path:
    return METADATA_DIR / f"{video_id}.json"


def _read_metadata(video_id: str) -> dict:
    path = _metadata_path(video_id)
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Video not found")
    return json.loads(path.read_text(encoding="utf-8"))


def _inspect_video(path: Path, video_id: str) -> dict:
    capture = cv2.VideoCapture(str(path))
    try:
        if not capture.isOpened():
            raise ValueError("The uploaded file could not be opened as a video.")
        frame_count = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = float(capture.get(cv2.CAP_PROP_FPS))
        width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
        if frame_count <= 0 or fps <= 0 or width <= 0 or height <= 0:
            raise ValueError("Video metadata is incomplete; the file may be damaged or unsupported.")
        duration = frame_count / fps
        if duration <= 0:
            raise ValueError("Video duration could not be determined.")
        # Read a frame near the beginning for a preview; this never alters the original.
        capture.set(cv2.CAP_PROP_POS_MSEC, min(1000.0, duration * 100.0))
        ok, frame = capture.read()
        if not ok:
            capture.set(cv2.CAP_PROP_POS_FRAMES, 0)
            ok, frame = capture.read()
        if not ok:
            raise ValueError("The video opened, but no decodable preview frame was found.")
        thumbnail_name = f"{video_id}.jpg"
        thumbnail_path = THUMBNAILS_DIR / thumbnail_name
        if not cv2.imwrite(str(thumbnail_path), frame, [cv2.IMWRITE_JPEG_QUALITY, 88]):
            raise ValueError("Could not generate the video thumbnail.")
        return {
            "duration_seconds": round(duration, 3),
            "fps": round(fps, 3),
            "frame_count": frame_count,
            "width": width,
            "height": height,
            "thumbnail_url": f"/storage/thumbnails/{thumbnail_name}",
        }
    finally:
        capture.release()


@app.get("/health", tags=["system"])
def health() -> dict[str, str]:
    return {"status": "ok", "service": "atmface-local", "mode": "local-prototype"}


@app.post("/videos/upload", tags=["videos"])
async def upload_video(file: UploadFile = File(...)) -> dict:
    original_name = Path(file.filename or "upload").name
    extension = Path(original_name).suffix.lower()
    if extension not in ALLOWED_EXTENSIONS:
        raise HTTPException(status_code=415, detail="Unsupported format. Upload MP4, AVI or MKV.")

    video_id = str(uuid.uuid4())
    temporary_path = TEMP_DIR / f"{video_id}.upload"
    digest = hashlib.sha256()
    total_bytes = 0
    try:
        with temporary_path.open("xb") as destination:
            while chunk := await file.read(CHUNK_SIZE):
                total_bytes += len(chunk)
                if total_bytes > MAX_UPLOAD_BYTES:
                    raise HTTPException(
                        status_code=413,
                        detail=f"File exceeds the {MAX_UPLOAD_BYTES // (1024 * 1024)} MB upload limit.",
                    )
                digest.update(chunk)
                destination.write(chunk)
        if total_bytes == 0:
            raise HTTPException(status_code=400, detail="The uploaded file is empty.")

        final_path = ORIGINALS_DIR / f"{video_id}{extension}"
        shutil.move(str(temporary_path), str(final_path))
        try:
            technical = _inspect_video(final_path, video_id)
        except ValueError as error:
            final_path.unlink(missing_ok=True)
            raise HTTPException(status_code=422, detail=str(error)) from error

        record = {
            "video_id": video_id,
            "original_filename": original_name,
            "stored_filename": final_path.name,
            "format": extension.lstrip("."),
            "size_bytes": total_bytes,
            "sha256": digest.hexdigest(),
            "uploaded_at": datetime.now(timezone.utc).isoformat(),
            "processing_status": "uploaded",
            "integrity_note": "SHA-256 calculated from uploaded bytes; original stored unchanged.",
            **technical,
        }
        _metadata_path(video_id).write_text(json.dumps(record, indent=2), encoding="utf-8")
        return record
    finally:
        temporary_path.unlink(missing_ok=True)
        await file.close()


@app.get("/videos", tags=["videos"])
def list_videos() -> dict:
    records = []
    for path in sorted(METADATA_DIR.glob("*.json"), key=lambda item: item.stat().st_mtime, reverse=True):
        records.append(json.loads(path.read_text(encoding="utf-8")))
    return {"items": records, "count": len(records)}


@app.get("/videos/{video_id}", tags=["videos"])
def get_video(video_id: str) -> dict:
    return _read_metadata(video_id)
