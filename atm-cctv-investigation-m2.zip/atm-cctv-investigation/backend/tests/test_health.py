from fastapi.testclient import TestClient

from atmface.main import app

client = TestClient(app)


def test_health_endpoint() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_video_list_starts_empty_or_returns_items() -> None:
    response = client.get("/videos")
    assert response.status_code == 200
    assert isinstance(response.json()["items"], list)


def test_rejects_unsupported_extension() -> None:
    response = client.post("/videos/upload", files={"file": ("notes.txt", b"not a video")})
    assert response.status_code == 415
